
#ifndef glxw_h
#define glxw_h

struct glxw;

#include <GL/glcorearb.h>


#ifndef __gl_h_
#define __gl_h_
#endif

#ifdef __cplusplus
extern "C" {
#endif

int glxwInit(void);
int glxwInitCtx(struct glxw *ctx);

struct glxw {
PFNGLCULLFACEPROC _glCullFace;
PFNGLFRONTFACEPROC _glFrontFace;
PFNGLHINTPROC _glHint;
PFNGLLINEWIDTHPROC _glLineWidth;
PFNGLPOINTSIZEPROC _glPointSize;
PFNGLPOLYGONMODEPROC _glPolygonMode;
PFNGLSCISSORPROC _glScissor;
PFNGLTEXPARAMETERFPROC _glTexParameterf;
PFNGLTEXPARAMETERFVPROC _glTexParameterfv;
PFNGLTEXPARAMETERIPROC _glTexParameteri;
PFNGLTEXPARAMETERIVPROC _glTexParameteriv;
PFNGLTEXIMAGE1DPROC _glTexImage1D;
PFNGLTEXIMAGE2DPROC _glTexImage2D;
PFNGLDRAWBUFFERPROC _glDrawBuffer;
PFNGLCLEARPROC _glClear;
PFNGLCLEARCOLORPROC _glClearColor;
PFNGLCLEARSTENCILPROC _glClearStencil;
PFNGLCLEARDEPTHPROC _glClearDepth;
PFNGLSTENCILMASKPROC _glStencilMask;
PFNGLCOLORMASKPROC _glColorMask;
PFNGLDEPTHMASKPROC _glDepthMask;
PFNGLDISABLEPROC _glDisable;
PFNGLENABLEPROC _glEnable;
PFNGLFINISHPROC _glFinish;
PFNGLFLUSHPROC _glFlush;
PFNGLBLENDFUNCPROC _glBlendFunc;
PFNGLLOGICOPPROC _glLogicOp;
PFNGLSTENCILFUNCPROC _glStencilFunc;
PFNGLSTENCILOPPROC _glStencilOp;
PFNGLDEPTHFUNCPROC _glDepthFunc;
PFNGLPIXELSTOREFPROC _glPixelStoref;
PFNGLPIXELSTOREIPROC _glPixelStorei;
PFNGLREADBUFFERPROC _glReadBuffer;
PFNGLREADPIXELSPROC _glReadPixels;
PFNGLGETBOOLEANVPROC _glGetBooleanv;
PFNGLGETDOUBLEVPROC _glGetDoublev;
PFNGLGETERRORPROC _glGetError;
PFNGLGETFLOATVPROC _glGetFloatv;
PFNGLGETINTEGERVPROC _glGetIntegerv;
PFNGLGETSTRINGPROC _glGetString;
PFNGLGETTEXIMAGEPROC _glGetTexImage;
PFNGLGETTEXPARAMETERFVPROC _glGetTexParameterfv;
PFNGLGETTEXPARAMETERIVPROC _glGetTexParameteriv;
PFNGLGETTEXLEVELPARAMETERFVPROC _glGetTexLevelParameterfv;
PFNGLGETTEXLEVELPARAMETERIVPROC _glGetTexLevelParameteriv;
PFNGLISENABLEDPROC _glIsEnabled;
PFNGLDEPTHRANGEPROC _glDepthRange;
PFNGLVIEWPORTPROC _glViewport;
PFNGLDRAWARRAYSPROC _glDrawArrays;
PFNGLDRAWELEMENTSPROC _glDrawElements;
PFNGLGETPOINTERVPROC _glGetPointerv;
PFNGLPOLYGONOFFSETPROC _glPolygonOffset;
PFNGLCOPYTEXIMAGE1DPROC _glCopyTexImage1D;
PFNGLCOPYTEXIMAGE2DPROC _glCopyTexImage2D;
PFNGLCOPYTEXSUBIMAGE1DPROC _glCopyTexSubImage1D;
PFNGLCOPYTEXSUBIMAGE2DPROC _glCopyTexSubImage2D;
PFNGLTEXSUBIMAGE1DPROC _glTexSubImage1D;
PFNGLTEXSUBIMAGE2DPROC _glTexSubImage2D;
PFNGLBINDTEXTUREPROC _glBindTexture;
PFNGLDELETETEXTURESPROC _glDeleteTextures;
PFNGLGENTEXTURESPROC _glGenTextures;
PFNGLISTEXTUREPROC _glIsTexture;
PFNGLBLENDCOLORPROC _glBlendColor;
PFNGLBLENDEQUATIONPROC _glBlendEquation;
PFNGLDRAWRANGEELEMENTSPROC _glDrawRangeElements;
PFNGLTEXIMAGE3DPROC _glTexImage3D;
PFNGLTEXSUBIMAGE3DPROC _glTexSubImage3D;
PFNGLCOPYTEXSUBIMAGE3DPROC _glCopyTexSubImage3D;
PFNGLACTIVETEXTUREPROC _glActiveTexture;
PFNGLSAMPLECOVERAGEPROC _glSampleCoverage;
PFNGLCOMPRESSEDTEXIMAGE3DPROC _glCompressedTexImage3D;
PFNGLCOMPRESSEDTEXIMAGE2DPROC _glCompressedTexImage2D;
PFNGLCOMPRESSEDTEXIMAGE1DPROC _glCompressedTexImage1D;
PFNGLCOMPRESSEDTEXSUBIMAGE3DPROC _glCompressedTexSubImage3D;
PFNGLCOMPRESSEDTEXSUBIMAGE2DPROC _glCompressedTexSubImage2D;
PFNGLCOMPRESSEDTEXSUBIMAGE1DPROC _glCompressedTexSubImage1D;
PFNGLGETCOMPRESSEDTEXIMAGEPROC _glGetCompressedTexImage;
PFNGLBLENDFUNCSEPARATEPROC _glBlendFuncSeparate;
PFNGLMULTIDRAWARRAYSPROC _glMultiDrawArrays;
PFNGLMULTIDRAWELEMENTSPROC _glMultiDrawElements;
PFNGLPOINTPARAMETERFPROC _glPointParameterf;
PFNGLPOINTPARAMETERFVPROC _glPointParameterfv;
PFNGLPOINTPARAMETERIPROC _glPointParameteri;
PFNGLPOINTPARAMETERIVPROC _glPointParameteriv;
PFNGLGENQUERIESPROC _glGenQueries;
PFNGLDELETEQUERIESPROC _glDeleteQueries;
PFNGLISQUERYPROC _glIsQuery;
PFNGLBEGINQUERYPROC _glBeginQuery;
PFNGLENDQUERYPROC _glEndQuery;
PFNGLGETQUERYIVPROC _glGetQueryiv;
PFNGLGETQUERYOBJECTIVPROC _glGetQueryObjectiv;
PFNGLGETQUERYOBJECTUIVPROC _glGetQueryObjectuiv;
PFNGLBINDBUFFERPROC _glBindBuffer;
PFNGLDELETEBUFFERSPROC _glDeleteBuffers;
PFNGLGENBUFFERSPROC _glGenBuffers;
PFNGLISBUFFERPROC _glIsBuffer;
PFNGLBUFFERDATAPROC _glBufferData;
PFNGLBUFFERSUBDATAPROC _glBufferSubData;
PFNGLGETBUFFERSUBDATAPROC _glGetBufferSubData;
PFNGLMAPBUFFERPROC _glMapBuffer;
PFNGLUNMAPBUFFERPROC _glUnmapBuffer;
PFNGLGETBUFFERPARAMETERIVPROC _glGetBufferParameteriv;
PFNGLGETBUFFERPOINTERVPROC _glGetBufferPointerv;
PFNGLBLENDEQUATIONSEPARATEPROC _glBlendEquationSeparate;
PFNGLDRAWBUFFERSPROC _glDrawBuffers;
PFNGLSTENCILOPSEPARATEPROC _glStencilOpSeparate;
PFNGLSTENCILFUNCSEPARATEPROC _glStencilFuncSeparate;
PFNGLSTENCILMASKSEPARATEPROC _glStencilMaskSeparate;
PFNGLATTACHSHADERPROC _glAttachShader;
PFNGLBINDATTRIBLOCATIONPROC _glBindAttribLocation;
PFNGLCOMPILESHADERPROC _glCompileShader;
PFNGLCREATEPROGRAMPROC _glCreateProgram;
PFNGLCREATESHADERPROC _glCreateShader;
PFNGLDELETEPROGRAMPROC _glDeleteProgram;
PFNGLDELETESHADERPROC _glDeleteShader;
PFNGLDETACHSHADERPROC _glDetachShader;
PFNGLDISABLEVERTEXATTRIBARRAYPROC _glDisableVertexAttribArray;
PFNGLENABLEVERTEXATTRIBARRAYPROC _glEnableVertexAttribArray;
PFNGLGETACTIVEATTRIBPROC _glGetActiveAttrib;
PFNGLGETACTIVEUNIFORMPROC _glGetActiveUniform;
PFNGLGETATTACHEDSHADERSPROC _glGetAttachedShaders;
PFNGLGETATTRIBLOCATIONPROC _glGetAttribLocation;
PFNGLGETPROGRAMIVPROC _glGetProgramiv;
PFNGLGETPROGRAMINFOLOGPROC _glGetProgramInfoLog;
PFNGLGETSHADERIVPROC _glGetShaderiv;
PFNGLGETSHADERINFOLOGPROC _glGetShaderInfoLog;
PFNGLGETSHADERSOURCEPROC _glGetShaderSource;
PFNGLGETUNIFORMLOCATIONPROC _glGetUniformLocation;
PFNGLGETUNIFORMFVPROC _glGetUniformfv;
PFNGLGETUNIFORMIVPROC _glGetUniformiv;
PFNGLGETVERTEXATTRIBDVPROC _glGetVertexAttribdv;
PFNGLGETVERTEXATTRIBFVPROC _glGetVertexAttribfv;
PFNGLGETVERTEXATTRIBIVPROC _glGetVertexAttribiv;
PFNGLGETVERTEXATTRIBPOINTERVPROC _glGetVertexAttribPointerv;
PFNGLISPROGRAMPROC _glIsProgram;
PFNGLISSHADERPROC _glIsShader;
PFNGLLINKPROGRAMPROC _glLinkProgram;
PFNGLSHADERSOURCEPROC _glShaderSource;
PFNGLUSEPROGRAMPROC _glUseProgram;
PFNGLUNIFORM1FPROC _glUniform1f;
PFNGLUNIFORM2FPROC _glUniform2f;
PFNGLUNIFORM3FPROC _glUniform3f;
PFNGLUNIFORM4FPROC _glUniform4f;
PFNGLUNIFORM1IPROC _glUniform1i;
PFNGLUNIFORM2IPROC _glUniform2i;
PFNGLUNIFORM3IPROC _glUniform3i;
PFNGLUNIFORM4IPROC _glUniform4i;
PFNGLUNIFORM1FVPROC _glUniform1fv;
PFNGLUNIFORM2FVPROC _glUniform2fv;
PFNGLUNIFORM3FVPROC _glUniform3fv;
PFNGLUNIFORM4FVPROC _glUniform4fv;
PFNGLUNIFORM1IVPROC _glUniform1iv;
PFNGLUNIFORM2IVPROC _glUniform2iv;
PFNGLUNIFORM3IVPROC _glUniform3iv;
PFNGLUNIFORM4IVPROC _glUniform4iv;
PFNGLUNIFORMMATRIX2FVPROC _glUniformMatrix2fv;
PFNGLUNIFORMMATRIX3FVPROC _glUniformMatrix3fv;
PFNGLUNIFORMMATRIX4FVPROC _glUniformMatrix4fv;
PFNGLVALIDATEPROGRAMPROC _glValidateProgram;
PFNGLVERTEXATTRIB1DPROC _glVertexAttrib1d;
PFNGLVERTEXATTRIB1DVPROC _glVertexAttrib1dv;
PFNGLVERTEXATTRIB1FPROC _glVertexAttrib1f;
PFNGLVERTEXATTRIB1FVPROC _glVertexAttrib1fv;
PFNGLVERTEXATTRIB1SPROC _glVertexAttrib1s;
PFNGLVERTEXATTRIB1SVPROC _glVertexAttrib1sv;
PFNGLVERTEXATTRIB2DPROC _glVertexAttrib2d;
PFNGLVERTEXATTRIB2DVPROC _glVertexAttrib2dv;
PFNGLVERTEXATTRIB2FPROC _glVertexAttrib2f;
PFNGLVERTEXATTRIB2FVPROC _glVertexAttrib2fv;
PFNGLVERTEXATTRIB2SPROC _glVertexAttrib2s;
PFNGLVERTEXATTRIB2SVPROC _glVertexAttrib2sv;
PFNGLVERTEXATTRIB3DPROC _glVertexAttrib3d;
PFNGLVERTEXATTRIB3DVPROC _glVertexAttrib3dv;
PFNGLVERTEXATTRIB3FPROC _glVertexAttrib3f;
PFNGLVERTEXATTRIB3FVPROC _glVertexAttrib3fv;
PFNGLVERTEXATTRIB3SPROC _glVertexAttrib3s;
PFNGLVERTEXATTRIB3SVPROC _glVertexAttrib3sv;
PFNGLVERTEXATTRIB4NBVPROC _glVertexAttrib4Nbv;
PFNGLVERTEXATTRIB4NIVPROC _glVertexAttrib4Niv;
PFNGLVERTEXATTRIB4NSVPROC _glVertexAttrib4Nsv;
PFNGLVERTEXATTRIB4NUBPROC _glVertexAttrib4Nub;
PFNGLVERTEXATTRIB4NUBVPROC _glVertexAttrib4Nubv;
PFNGLVERTEXATTRIB4NUIVPROC _glVertexAttrib4Nuiv;
PFNGLVERTEXATTRIB4NUSVPROC _glVertexAttrib4Nusv;
PFNGLVERTEXATTRIB4BVPROC _glVertexAttrib4bv;
PFNGLVERTEXATTRIB4DPROC _glVertexAttrib4d;
PFNGLVERTEXATTRIB4DVPROC _glVertexAttrib4dv;
PFNGLVERTEXATTRIB4FPROC _glVertexAttrib4f;
PFNGLVERTEXATTRIB4FVPROC _glVertexAttrib4fv;
PFNGLVERTEXATTRIB4IVPROC _glVertexAttrib4iv;
PFNGLVERTEXATTRIB4SPROC _glVertexAttrib4s;
PFNGLVERTEXATTRIB4SVPROC _glVertexAttrib4sv;
PFNGLVERTEXATTRIB4UBVPROC _glVertexAttrib4ubv;
PFNGLVERTEXATTRIB4UIVPROC _glVertexAttrib4uiv;
PFNGLVERTEXATTRIB4USVPROC _glVertexAttrib4usv;
PFNGLVERTEXATTRIBPOINTERPROC _glVertexAttribPointer;
PFNGLUNIFORMMATRIX2X3FVPROC _glUniformMatrix2x3fv;
PFNGLUNIFORMMATRIX3X2FVPROC _glUniformMatrix3x2fv;
PFNGLUNIFORMMATRIX2X4FVPROC _glUniformMatrix2x4fv;
PFNGLUNIFORMMATRIX4X2FVPROC _glUniformMatrix4x2fv;
PFNGLUNIFORMMATRIX3X4FVPROC _glUniformMatrix3x4fv;
PFNGLUNIFORMMATRIX4X3FVPROC _glUniformMatrix4x3fv;
PFNGLCOLORMASKIPROC _glColorMaski;
PFNGLGETBOOLEANI_VPROC _glGetBooleani_v;
PFNGLGETINTEGERI_VPROC _glGetIntegeri_v;
PFNGLENABLEIPROC _glEnablei;
PFNGLDISABLEIPROC _glDisablei;
PFNGLISENABLEDIPROC _glIsEnabledi;
PFNGLBEGINTRANSFORMFEEDBACKPROC _glBeginTransformFeedback;
PFNGLENDTRANSFORMFEEDBACKPROC _glEndTransformFeedback;
PFNGLBINDBUFFERRANGEPROC _glBindBufferRange;
PFNGLBINDBUFFERBASEPROC _glBindBufferBase;
PFNGLTRANSFORMFEEDBACKVARYINGSPROC _glTransformFeedbackVaryings;
PFNGLGETTRANSFORMFEEDBACKVARYINGPROC _glGetTransformFeedbackVarying;
PFNGLCLAMPCOLORPROC _glClampColor;
PFNGLBEGINCONDITIONALRENDERPROC _glBeginConditionalRender;
PFNGLENDCONDITIONALRENDERPROC _glEndConditionalRender;
PFNGLVERTEXATTRIBIPOINTERPROC _glVertexAttribIPointer;
PFNGLGETVERTEXATTRIBIIVPROC _glGetVertexAttribIiv;
PFNGLGETVERTEXATTRIBIUIVPROC _glGetVertexAttribIuiv;
PFNGLVERTEXATTRIBI1IPROC _glVertexAttribI1i;
PFNGLVERTEXATTRIBI2IPROC _glVertexAttribI2i;
PFNGLVERTEXATTRIBI3IPROC _glVertexAttribI3i;
PFNGLVERTEXATTRIBI4IPROC _glVertexAttribI4i;
PFNGLVERTEXATTRIBI1UIPROC _glVertexAttribI1ui;
PFNGLVERTEXATTRIBI2UIPROC _glVertexAttribI2ui;
PFNGLVERTEXATTRIBI3UIPROC _glVertexAttribI3ui;
PFNGLVERTEXATTRIBI4UIPROC _glVertexAttribI4ui;
PFNGLVERTEXATTRIBI1IVPROC _glVertexAttribI1iv;
PFNGLVERTEXATTRIBI2IVPROC _glVertexAttribI2iv;
PFNGLVERTEXATTRIBI3IVPROC _glVertexAttribI3iv;
PFNGLVERTEXATTRIBI4IVPROC _glVertexAttribI4iv;
PFNGLVERTEXATTRIBI1UIVPROC _glVertexAttribI1uiv;
PFNGLVERTEXATTRIBI2UIVPROC _glVertexAttribI2uiv;
PFNGLVERTEXATTRIBI3UIVPROC _glVertexAttribI3uiv;
PFNGLVERTEXATTRIBI4UIVPROC _glVertexAttribI4uiv;
PFNGLVERTEXATTRIBI4BVPROC _glVertexAttribI4bv;
PFNGLVERTEXATTRIBI4SVPROC _glVertexAttribI4sv;
PFNGLVERTEXATTRIBI4UBVPROC _glVertexAttribI4ubv;
PFNGLVERTEXATTRIBI4USVPROC _glVertexAttribI4usv;
PFNGLGETUNIFORMUIVPROC _glGetUniformuiv;
PFNGLBINDFRAGDATALOCATIONPROC _glBindFragDataLocation;
PFNGLGETFRAGDATALOCATIONPROC _glGetFragDataLocation;
PFNGLUNIFORM1UIPROC _glUniform1ui;
PFNGLUNIFORM2UIPROC _glUniform2ui;
PFNGLUNIFORM3UIPROC _glUniform3ui;
PFNGLUNIFORM4UIPROC _glUniform4ui;
PFNGLUNIFORM1UIVPROC _glUniform1uiv;
PFNGLUNIFORM2UIVPROC _glUniform2uiv;
PFNGLUNIFORM3UIVPROC _glUniform3uiv;
PFNGLUNIFORM4UIVPROC _glUniform4uiv;
PFNGLTEXPARAMETERIIVPROC _glTexParameterIiv;
PFNGLTEXPARAMETERIUIVPROC _glTexParameterIuiv;
PFNGLGETTEXPARAMETERIIVPROC _glGetTexParameterIiv;
PFNGLGETTEXPARAMETERIUIVPROC _glGetTexParameterIuiv;
PFNGLCLEARBUFFERIVPROC _glClearBufferiv;
PFNGLCLEARBUFFERUIVPROC _glClearBufferuiv;
PFNGLCLEARBUFFERFVPROC _glClearBufferfv;
PFNGLCLEARBUFFERFIPROC _glClearBufferfi;
PFNGLGETSTRINGIPROC _glGetStringi;
PFNGLDRAWARRAYSINSTANCEDPROC _glDrawArraysInstanced;
PFNGLDRAWELEMENTSINSTANCEDPROC _glDrawElementsInstanced;
PFNGLTEXBUFFERPROC _glTexBuffer;
PFNGLPRIMITIVERESTARTINDEXPROC _glPrimitiveRestartIndex;
PFNGLGETINTEGER64I_VPROC _glGetInteger64i_v;
PFNGLGETBUFFERPARAMETERI64VPROC _glGetBufferParameteri64v;
PFNGLFRAMEBUFFERTEXTUREPROC _glFramebufferTexture;
PFNGLVERTEXATTRIBDIVISORPROC _glVertexAttribDivisor;
PFNGLMINSAMPLESHADINGPROC _glMinSampleShading;
PFNGLBLENDEQUATIONIPROC _glBlendEquationi;
PFNGLBLENDEQUATIONSEPARATEIPROC _glBlendEquationSeparatei;
PFNGLBLENDFUNCIPROC _glBlendFunci;
PFNGLBLENDFUNCSEPARATEIPROC _glBlendFuncSeparatei;
PFNGLISRENDERBUFFERPROC _glIsRenderbuffer;
PFNGLBINDRENDERBUFFERPROC _glBindRenderbuffer;
PFNGLDELETERENDERBUFFERSPROC _glDeleteRenderbuffers;
PFNGLGENRENDERBUFFERSPROC _glGenRenderbuffers;
PFNGLRENDERBUFFERSTORAGEPROC _glRenderbufferStorage;
PFNGLGETRENDERBUFFERPARAMETERIVPROC _glGetRenderbufferParameteriv;
PFNGLISFRAMEBUFFERPROC _glIsFramebuffer;
PFNGLBINDFRAMEBUFFERPROC _glBindFramebuffer;
PFNGLDELETEFRAMEBUFFERSPROC _glDeleteFramebuffers;
PFNGLGENFRAMEBUFFERSPROC _glGenFramebuffers;
PFNGLCHECKFRAMEBUFFERSTATUSPROC _glCheckFramebufferStatus;
PFNGLFRAMEBUFFERTEXTURE1DPROC _glFramebufferTexture1D;
PFNGLFRAMEBUFFERTEXTURE2DPROC _glFramebufferTexture2D;
PFNGLFRAMEBUFFERTEXTURE3DPROC _glFramebufferTexture3D;
PFNGLFRAMEBUFFERRENDERBUFFERPROC _glFramebufferRenderbuffer;
PFNGLGETFRAMEBUFFERATTACHMENTPARAMETERIVPROC _glGetFramebufferAttachmentParameteriv;
PFNGLGENERATEMIPMAPPROC _glGenerateMipmap;
PFNGLBLITFRAMEBUFFERPROC _glBlitFramebuffer;
PFNGLRENDERBUFFERSTORAGEMULTISAMPLEPROC _glRenderbufferStorageMultisample;
PFNGLFRAMEBUFFERTEXTURELAYERPROC _glFramebufferTextureLayer;
PFNGLMAPBUFFERRANGEPROC _glMapBufferRange;
PFNGLFLUSHMAPPEDBUFFERRANGEPROC _glFlushMappedBufferRange;
PFNGLBINDVERTEXARRAYPROC _glBindVertexArray;
PFNGLDELETEVERTEXARRAYSPROC _glDeleteVertexArrays;
PFNGLGENVERTEXARRAYSPROC _glGenVertexArrays;
PFNGLISVERTEXARRAYPROC _glIsVertexArray;
PFNGLGETUNIFORMINDICESPROC _glGetUniformIndices;
PFNGLGETACTIVEUNIFORMSIVPROC _glGetActiveUniformsiv;
PFNGLGETACTIVEUNIFORMNAMEPROC _glGetActiveUniformName;
PFNGLGETUNIFORMBLOCKINDEXPROC _glGetUniformBlockIndex;
PFNGLGETACTIVEUNIFORMBLOCKIVPROC _glGetActiveUniformBlockiv;
PFNGLGETACTIVEUNIFORMBLOCKNAMEPROC _glGetActiveUniformBlockName;
PFNGLUNIFORMBLOCKBINDINGPROC _glUniformBlockBinding;
PFNGLCOPYBUFFERSUBDATAPROC _glCopyBufferSubData;
PFNGLDRAWELEMENTSBASEVERTEXPROC _glDrawElementsBaseVertex;
PFNGLDRAWRANGEELEMENTSBASEVERTEXPROC _glDrawRangeElementsBaseVertex;
PFNGLDRAWELEMENTSINSTANCEDBASEVERTEXPROC _glDrawElementsInstancedBaseVertex;
PFNGLMULTIDRAWELEMENTSBASEVERTEXPROC _glMultiDrawElementsBaseVertex;
PFNGLPROVOKINGVERTEXPROC _glProvokingVertex;
PFNGLFENCESYNCPROC _glFenceSync;
PFNGLISSYNCPROC _glIsSync;
PFNGLDELETESYNCPROC _glDeleteSync;
PFNGLCLIENTWAITSYNCPROC _glClientWaitSync;
PFNGLWAITSYNCPROC _glWaitSync;
PFNGLGETINTEGER64VPROC _glGetInteger64v;
PFNGLGETSYNCIVPROC _glGetSynciv;
PFNGLTEXIMAGE2DMULTISAMPLEPROC _glTexImage2DMultisample;
PFNGLTEXIMAGE3DMULTISAMPLEPROC _glTexImage3DMultisample;
PFNGLGETMULTISAMPLEFVPROC _glGetMultisamplefv;
PFNGLSAMPLEMASKIPROC _glSampleMaski;
PFNGLBLENDEQUATIONIARBPROC _glBlendEquationiARB;
PFNGLBLENDEQUATIONSEPARATEIARBPROC _glBlendEquationSeparateiARB;
PFNGLBLENDFUNCIARBPROC _glBlendFunciARB;
PFNGLBLENDFUNCSEPARATEIARBPROC _glBlendFuncSeparateiARB;
PFNGLMINSAMPLESHADINGARBPROC _glMinSampleShadingARB;
PFNGLNAMEDSTRINGARBPROC _glNamedStringARB;
PFNGLDELETENAMEDSTRINGARBPROC _glDeleteNamedStringARB;
PFNGLCOMPILESHADERINCLUDEARBPROC _glCompileShaderIncludeARB;
PFNGLISNAMEDSTRINGARBPROC _glIsNamedStringARB;
PFNGLGETNAMEDSTRINGARBPROC _glGetNamedStringARB;
PFNGLGETNAMEDSTRINGIVARBPROC _glGetNamedStringivARB;
PFNGLBINDFRAGDATALOCATIONINDEXEDPROC _glBindFragDataLocationIndexed;
PFNGLGETFRAGDATAINDEXPROC _glGetFragDataIndex;
PFNGLGENSAMPLERSPROC _glGenSamplers;
PFNGLDELETESAMPLERSPROC _glDeleteSamplers;
PFNGLISSAMPLERPROC _glIsSampler;
PFNGLBINDSAMPLERPROC _glBindSampler;
PFNGLSAMPLERPARAMETERIPROC _glSamplerParameteri;
PFNGLSAMPLERPARAMETERIVPROC _glSamplerParameteriv;
PFNGLSAMPLERPARAMETERFPROC _glSamplerParameterf;
PFNGLSAMPLERPARAMETERFVPROC _glSamplerParameterfv;
PFNGLSAMPLERPARAMETERIIVPROC _glSamplerParameterIiv;
PFNGLSAMPLERPARAMETERIUIVPROC _glSamplerParameterIuiv;
PFNGLGETSAMPLERPARAMETERIVPROC _glGetSamplerParameteriv;
PFNGLGETSAMPLERPARAMETERIIVPROC _glGetSamplerParameterIiv;
PFNGLGETSAMPLERPARAMETERFVPROC _glGetSamplerParameterfv;
PFNGLGETSAMPLERPARAMETERIUIVPROC _glGetSamplerParameterIuiv;
PFNGLQUERYCOUNTERPROC _glQueryCounter;
PFNGLGETQUERYOBJECTI64VPROC _glGetQueryObjecti64v;
PFNGLGETQUERYOBJECTUI64VPROC _glGetQueryObjectui64v;
PFNGLVERTEXP2UIPROC _glVertexP2ui;
PFNGLVERTEXP2UIVPROC _glVertexP2uiv;
PFNGLVERTEXP3UIPROC _glVertexP3ui;
PFNGLVERTEXP3UIVPROC _glVertexP3uiv;
PFNGLVERTEXP4UIPROC _glVertexP4ui;
PFNGLVERTEXP4UIVPROC _glVertexP4uiv;
PFNGLTEXCOORDP1UIPROC _glTexCoordP1ui;
PFNGLTEXCOORDP1UIVPROC _glTexCoordP1uiv;
PFNGLTEXCOORDP2UIPROC _glTexCoordP2ui;
PFNGLTEXCOORDP2UIVPROC _glTexCoordP2uiv;
PFNGLTEXCOORDP3UIPROC _glTexCoordP3ui;
PFNGLTEXCOORDP3UIVPROC _glTexCoordP3uiv;
PFNGLTEXCOORDP4UIPROC _glTexCoordP4ui;
PFNGLTEXCOORDP4UIVPROC _glTexCoordP4uiv;
PFNGLMULTITEXCOORDP1UIPROC _glMultiTexCoordP1ui;
PFNGLMULTITEXCOORDP1UIVPROC _glMultiTexCoordP1uiv;
PFNGLMULTITEXCOORDP2UIPROC _glMultiTexCoordP2ui;
PFNGLMULTITEXCOORDP2UIVPROC _glMultiTexCoordP2uiv;
PFNGLMULTITEXCOORDP3UIPROC _glMultiTexCoordP3ui;
PFNGLMULTITEXCOORDP3UIVPROC _glMultiTexCoordP3uiv;
PFNGLMULTITEXCOORDP4UIPROC _glMultiTexCoordP4ui;
PFNGLMULTITEXCOORDP4UIVPROC _glMultiTexCoordP4uiv;
PFNGLNORMALP3UIPROC _glNormalP3ui;
PFNGLNORMALP3UIVPROC _glNormalP3uiv;
PFNGLCOLORP3UIPROC _glColorP3ui;
PFNGLCOLORP3UIVPROC _glColorP3uiv;
PFNGLCOLORP4UIPROC _glColorP4ui;
PFNGLCOLORP4UIVPROC _glColorP4uiv;
PFNGLSECONDARYCOLORP3UIPROC _glSecondaryColorP3ui;
PFNGLSECONDARYCOLORP3UIVPROC _glSecondaryColorP3uiv;
PFNGLVERTEXATTRIBP1UIPROC _glVertexAttribP1ui;
PFNGLVERTEXATTRIBP1UIVPROC _glVertexAttribP1uiv;
PFNGLVERTEXATTRIBP2UIPROC _glVertexAttribP2ui;
PFNGLVERTEXATTRIBP2UIVPROC _glVertexAttribP2uiv;
PFNGLVERTEXATTRIBP3UIPROC _glVertexAttribP3ui;
PFNGLVERTEXATTRIBP3UIVPROC _glVertexAttribP3uiv;
PFNGLVERTEXATTRIBP4UIPROC _glVertexAttribP4ui;
PFNGLVERTEXATTRIBP4UIVPROC _glVertexAttribP4uiv;
PFNGLDRAWARRAYSINDIRECTPROC _glDrawArraysIndirect;
PFNGLDRAWELEMENTSINDIRECTPROC _glDrawElementsIndirect;
PFNGLUNIFORM1DPROC _glUniform1d;
PFNGLUNIFORM2DPROC _glUniform2d;
PFNGLUNIFORM3DPROC _glUniform3d;
PFNGLUNIFORM4DPROC _glUniform4d;
PFNGLUNIFORM1DVPROC _glUniform1dv;
PFNGLUNIFORM2DVPROC _glUniform2dv;
PFNGLUNIFORM3DVPROC _glUniform3dv;
PFNGLUNIFORM4DVPROC _glUniform4dv;
PFNGLUNIFORMMATRIX2DVPROC _glUniformMatrix2dv;
PFNGLUNIFORMMATRIX3DVPROC _glUniformMatrix3dv;
PFNGLUNIFORMMATRIX4DVPROC _glUniformMatrix4dv;
PFNGLUNIFORMMATRIX2X3DVPROC _glUniformMatrix2x3dv;
PFNGLUNIFORMMATRIX2X4DVPROC _glUniformMatrix2x4dv;
PFNGLUNIFORMMATRIX3X2DVPROC _glUniformMatrix3x2dv;
PFNGLUNIFORMMATRIX3X4DVPROC _glUniformMatrix3x4dv;
PFNGLUNIFORMMATRIX4X2DVPROC _glUniformMatrix4x2dv;
PFNGLUNIFORMMATRIX4X3DVPROC _glUniformMatrix4x3dv;
PFNGLGETUNIFORMDVPROC _glGetUniformdv;
PFNGLGETSUBROUTINEUNIFORMLOCATIONPROC _glGetSubroutineUniformLocation;
PFNGLGETSUBROUTINEINDEXPROC _glGetSubroutineIndex;
PFNGLGETACTIVESUBROUTINEUNIFORMIVPROC _glGetActiveSubroutineUniformiv;
PFNGLGETACTIVESUBROUTINEUNIFORMNAMEPROC _glGetActiveSubroutineUniformName;
PFNGLGETACTIVESUBROUTINENAMEPROC _glGetActiveSubroutineName;
PFNGLUNIFORMSUBROUTINESUIVPROC _glUniformSubroutinesuiv;
PFNGLGETUNIFORMSUBROUTINEUIVPROC _glGetUniformSubroutineuiv;
PFNGLGETPROGRAMSTAGEIVPROC _glGetProgramStageiv;
PFNGLPATCHPARAMETERIPROC _glPatchParameteri;
PFNGLPATCHPARAMETERFVPROC _glPatchParameterfv;
PFNGLBINDTRANSFORMFEEDBACKPROC _glBindTransformFeedback;
PFNGLDELETETRANSFORMFEEDBACKSPROC _glDeleteTransformFeedbacks;
PFNGLGENTRANSFORMFEEDBACKSPROC _glGenTransformFeedbacks;
PFNGLISTRANSFORMFEEDBACKPROC _glIsTransformFeedback;
PFNGLPAUSETRANSFORMFEEDBACKPROC _glPauseTransformFeedback;
PFNGLRESUMETRANSFORMFEEDBACKPROC _glResumeTransformFeedback;
PFNGLDRAWTRANSFORMFEEDBACKPROC _glDrawTransformFeedback;
PFNGLDRAWTRANSFORMFEEDBACKSTREAMPROC _glDrawTransformFeedbackStream;
PFNGLBEGINQUERYINDEXEDPROC _glBeginQueryIndexed;
PFNGLENDQUERYINDEXEDPROC _glEndQueryIndexed;
PFNGLGETQUERYINDEXEDIVPROC _glGetQueryIndexediv;
PFNGLRELEASESHADERCOMPILERPROC _glReleaseShaderCompiler;
PFNGLSHADERBINARYPROC _glShaderBinary;
PFNGLGETSHADERPRECISIONFORMATPROC _glGetShaderPrecisionFormat;
PFNGLDEPTHRANGEFPROC _glDepthRangef;
PFNGLCLEARDEPTHFPROC _glClearDepthf;
PFNGLGETPROGRAMBINARYPROC _glGetProgramBinary;
PFNGLPROGRAMBINARYPROC _glProgramBinary;
PFNGLPROGRAMPARAMETERIPROC _glProgramParameteri;
PFNGLUSEPROGRAMSTAGESPROC _glUseProgramStages;
PFNGLACTIVESHADERPROGRAMPROC _glActiveShaderProgram;
PFNGLCREATESHADERPROGRAMVPROC _glCreateShaderProgramv;
PFNGLBINDPROGRAMPIPELINEPROC _glBindProgramPipeline;
PFNGLDELETEPROGRAMPIPELINESPROC _glDeleteProgramPipelines;
PFNGLGENPROGRAMPIPELINESPROC _glGenProgramPipelines;
PFNGLISPROGRAMPIPELINEPROC _glIsProgramPipeline;
PFNGLGETPROGRAMPIPELINEIVPROC _glGetProgramPipelineiv;
PFNGLPROGRAMUNIFORM1IPROC _glProgramUniform1i;
PFNGLPROGRAMUNIFORM1IVPROC _glProgramUniform1iv;
PFNGLPROGRAMUNIFORM1FPROC _glProgramUniform1f;
PFNGLPROGRAMUNIFORM1FVPROC _glProgramUniform1fv;
PFNGLPROGRAMUNIFORM1DPROC _glProgramUniform1d;
PFNGLPROGRAMUNIFORM1DVPROC _glProgramUniform1dv;
PFNGLPROGRAMUNIFORM1UIPROC _glProgramUniform1ui;
PFNGLPROGRAMUNIFORM1UIVPROC _glProgramUniform1uiv;
PFNGLPROGRAMUNIFORM2IPROC _glProgramUniform2i;
PFNGLPROGRAMUNIFORM2IVPROC _glProgramUniform2iv;
PFNGLPROGRAMUNIFORM2FPROC _glProgramUniform2f;
PFNGLPROGRAMUNIFORM2FVPROC _glProgramUniform2fv;
PFNGLPROGRAMUNIFORM2DPROC _glProgramUniform2d;
PFNGLPROGRAMUNIFORM2DVPROC _glProgramUniform2dv;
PFNGLPROGRAMUNIFORM2UIPROC _glProgramUniform2ui;
PFNGLPROGRAMUNIFORM2UIVPROC _glProgramUniform2uiv;
PFNGLPROGRAMUNIFORM3IPROC _glProgramUniform3i;
PFNGLPROGRAMUNIFORM3IVPROC _glProgramUniform3iv;
PFNGLPROGRAMUNIFORM3FPROC _glProgramUniform3f;
PFNGLPROGRAMUNIFORM3FVPROC _glProgramUniform3fv;
PFNGLPROGRAMUNIFORM3DPROC _glProgramUniform3d;
PFNGLPROGRAMUNIFORM3DVPROC _glProgramUniform3dv;
PFNGLPROGRAMUNIFORM3UIPROC _glProgramUniform3ui;
PFNGLPROGRAMUNIFORM3UIVPROC _glProgramUniform3uiv;
PFNGLPROGRAMUNIFORM4IPROC _glProgramUniform4i;
PFNGLPROGRAMUNIFORM4IVPROC _glProgramUniform4iv;
PFNGLPROGRAMUNIFORM4FPROC _glProgramUniform4f;
PFNGLPROGRAMUNIFORM4FVPROC _glProgramUniform4fv;
PFNGLPROGRAMUNIFORM4DPROC _glProgramUniform4d;
PFNGLPROGRAMUNIFORM4DVPROC _glProgramUniform4dv;
PFNGLPROGRAMUNIFORM4UIPROC _glProgramUniform4ui;
PFNGLPROGRAMUNIFORM4UIVPROC _glProgramUniform4uiv;
PFNGLPROGRAMUNIFORMMATRIX2FVPROC _glProgramUniformMatrix2fv;
PFNGLPROGRAMUNIFORMMATRIX3FVPROC _glProgramUniformMatrix3fv;
PFNGLPROGRAMUNIFORMMATRIX4FVPROC _glProgramUniformMatrix4fv;
PFNGLPROGRAMUNIFORMMATRIX2DVPROC _glProgramUniformMatrix2dv;
PFNGLPROGRAMUNIFORMMATRIX3DVPROC _glProgramUniformMatrix3dv;
PFNGLPROGRAMUNIFORMMATRIX4DVPROC _glProgramUniformMatrix4dv;
PFNGLPROGRAMUNIFORMMATRIX2X3FVPROC _glProgramUniformMatrix2x3fv;
PFNGLPROGRAMUNIFORMMATRIX3X2FVPROC _glProgramUniformMatrix3x2fv;
PFNGLPROGRAMUNIFORMMATRIX2X4FVPROC _glProgramUniformMatrix2x4fv;
PFNGLPROGRAMUNIFORMMATRIX4X2FVPROC _glProgramUniformMatrix4x2fv;
PFNGLPROGRAMUNIFORMMATRIX3X4FVPROC _glProgramUniformMatrix3x4fv;
PFNGLPROGRAMUNIFORMMATRIX4X3FVPROC _glProgramUniformMatrix4x3fv;
PFNGLPROGRAMUNIFORMMATRIX2X3DVPROC _glProgramUniformMatrix2x3dv;
PFNGLPROGRAMUNIFORMMATRIX3X2DVPROC _glProgramUniformMatrix3x2dv;
PFNGLPROGRAMUNIFORMMATRIX2X4DVPROC _glProgramUniformMatrix2x4dv;
PFNGLPROGRAMUNIFORMMATRIX4X2DVPROC _glProgramUniformMatrix4x2dv;
PFNGLPROGRAMUNIFORMMATRIX3X4DVPROC _glProgramUniformMatrix3x4dv;
PFNGLPROGRAMUNIFORMMATRIX4X3DVPROC _glProgramUniformMatrix4x3dv;
PFNGLVALIDATEPROGRAMPIPELINEPROC _glValidateProgramPipeline;
PFNGLGETPROGRAMPIPELINEINFOLOGPROC _glGetProgramPipelineInfoLog;
PFNGLVERTEXATTRIBL1DPROC _glVertexAttribL1d;
PFNGLVERTEXATTRIBL2DPROC _glVertexAttribL2d;
PFNGLVERTEXATTRIBL3DPROC _glVertexAttribL3d;
PFNGLVERTEXATTRIBL4DPROC _glVertexAttribL4d;
PFNGLVERTEXATTRIBL1DVPROC _glVertexAttribL1dv;
PFNGLVERTEXATTRIBL2DVPROC _glVertexAttribL2dv;
PFNGLVERTEXATTRIBL3DVPROC _glVertexAttribL3dv;
PFNGLVERTEXATTRIBL4DVPROC _glVertexAttribL4dv;
PFNGLVERTEXATTRIBLPOINTERPROC _glVertexAttribLPointer;
PFNGLGETVERTEXATTRIBLDVPROC _glGetVertexAttribLdv;
PFNGLVIEWPORTARRAYVPROC _glViewportArrayv;
PFNGLVIEWPORTINDEXEDFPROC _glViewportIndexedf;
PFNGLVIEWPORTINDEXEDFVPROC _glViewportIndexedfv;
PFNGLSCISSORARRAYVPROC _glScissorArrayv;
PFNGLSCISSORINDEXEDPROC _glScissorIndexed;
PFNGLSCISSORINDEXEDVPROC _glScissorIndexedv;
PFNGLDEPTHRANGEARRAYVPROC _glDepthRangeArrayv;
PFNGLDEPTHRANGEINDEXEDPROC _glDepthRangeIndexed;
PFNGLGETFLOATI_VPROC _glGetFloati_v;
PFNGLGETDOUBLEI_VPROC _glGetDoublei_v;
PFNGLCREATESYNCFROMCLEVENTARBPROC _glCreateSyncFromCLeventARB;
PFNGLDEBUGMESSAGECONTROLARBPROC _glDebugMessageControlARB;
PFNGLDEBUGMESSAGEINSERTARBPROC _glDebugMessageInsertARB;
PFNGLDEBUGMESSAGECALLBACKARBPROC _glDebugMessageCallbackARB;
PFNGLGETDEBUGMESSAGELOGARBPROC _glGetDebugMessageLogARB;
PFNGLGETGRAPHICSRESETSTATUSARBPROC _glGetGraphicsResetStatusARB;
PFNGLGETNTEXIMAGEARBPROC _glGetnTexImageARB;
PFNGLREADNPIXELSARBPROC _glReadnPixelsARB;
PFNGLGETNCOMPRESSEDTEXIMAGEARBPROC _glGetnCompressedTexImageARB;
PFNGLGETNUNIFORMFVARBPROC _glGetnUniformfvARB;
PFNGLGETNUNIFORMIVARBPROC _glGetnUniformivARB;
PFNGLGETNUNIFORMUIVARBPROC _glGetnUniformuivARB;
PFNGLGETNUNIFORMDVARBPROC _glGetnUniformdvARB;
PFNGLDRAWARRAYSINSTANCEDBASEINSTANCEPROC _glDrawArraysInstancedBaseInstance;
PFNGLDRAWELEMENTSINSTANCEDBASEINSTANCEPROC _glDrawElementsInstancedBaseInstance;
PFNGLDRAWELEMENTSINSTANCEDBASEVERTEXBASEINSTANCEPROC _glDrawElementsInstancedBaseVertexBaseInstance;
PFNGLDRAWTRANSFORMFEEDBACKINSTANCEDPROC _glDrawTransformFeedbackInstanced;
PFNGLDRAWTRANSFORMFEEDBACKSTREAMINSTANCEDPROC _glDrawTransformFeedbackStreamInstanced;
PFNGLGETINTERNALFORMATIVPROC _glGetInternalformativ;
PFNGLGETACTIVEATOMICCOUNTERBUFFERIVPROC _glGetActiveAtomicCounterBufferiv;
PFNGLBINDIMAGETEXTUREPROC _glBindImageTexture;
PFNGLMEMORYBARRIERPROC _glMemoryBarrier;
PFNGLTEXSTORAGE1DPROC _glTexStorage1D;
PFNGLTEXSTORAGE2DPROC _glTexStorage2D;
PFNGLTEXSTORAGE3DPROC _glTexStorage3D;
PFNGLTEXTURESTORAGE1DEXTPROC _glTextureStorage1DEXT;
PFNGLTEXTURESTORAGE2DEXTPROC _glTextureStorage2DEXT;
PFNGLTEXTURESTORAGE3DEXTPROC _glTextureStorage3DEXT;
PFNGLDEBUGMESSAGECONTROLPROC _glDebugMessageControl;
PFNGLDEBUGMESSAGEINSERTPROC _glDebugMessageInsert;
PFNGLDEBUGMESSAGECALLBACKPROC _glDebugMessageCallback;
PFNGLGETDEBUGMESSAGELOGPROC _glGetDebugMessageLog;
PFNGLPUSHDEBUGGROUPPROC _glPushDebugGroup;
PFNGLPOPDEBUGGROUPPROC _glPopDebugGroup;
PFNGLOBJECTLABELPROC _glObjectLabel;
PFNGLGETOBJECTLABELPROC _glGetObjectLabel;
PFNGLOBJECTPTRLABELPROC _glObjectPtrLabel;
PFNGLGETOBJECTPTRLABELPROC _glGetObjectPtrLabel;
PFNGLCLEARBUFFERDATAPROC _glClearBufferData;
PFNGLCLEARBUFFERSUBDATAPROC _glClearBufferSubData;
PFNGLCLEARNAMEDBUFFERDATAEXTPROC _glClearNamedBufferDataEXT;
PFNGLCLEARNAMEDBUFFERSUBDATAEXTPROC _glClearNamedBufferSubDataEXT;
PFNGLDISPATCHCOMPUTEPROC _glDispatchCompute;
PFNGLDISPATCHCOMPUTEINDIRECTPROC _glDispatchComputeIndirect;
PFNGLCOPYIMAGESUBDATAPROC _glCopyImageSubData;
PFNGLTEXTUREVIEWPROC _glTextureView;
PFNGLBINDVERTEXBUFFERPROC _glBindVertexBuffer;
PFNGLVERTEXATTRIBFORMATPROC _glVertexAttribFormat;
PFNGLVERTEXATTRIBIFORMATPROC _glVertexAttribIFormat;
PFNGLVERTEXATTRIBLFORMATPROC _glVertexAttribLFormat;
PFNGLVERTEXATTRIBBINDINGPROC _glVertexAttribBinding;
PFNGLVERTEXBINDINGDIVISORPROC _glVertexBindingDivisor;
PFNGLVERTEXARRAYBINDVERTEXBUFFEREXTPROC _glVertexArrayBindVertexBufferEXT;
PFNGLVERTEXARRAYVERTEXATTRIBFORMATEXTPROC _glVertexArrayVertexAttribFormatEXT;
PFNGLVERTEXARRAYVERTEXATTRIBIFORMATEXTPROC _glVertexArrayVertexAttribIFormatEXT;
PFNGLVERTEXARRAYVERTEXATTRIBLFORMATEXTPROC _glVertexArrayVertexAttribLFormatEXT;
PFNGLVERTEXARRAYVERTEXATTRIBBINDINGEXTPROC _glVertexArrayVertexAttribBindingEXT;
PFNGLVERTEXARRAYVERTEXBINDINGDIVISOREXTPROC _glVertexArrayVertexBindingDivisorEXT;
PFNGLFRAMEBUFFERPARAMETERIPROC _glFramebufferParameteri;
PFNGLGETFRAMEBUFFERPARAMETERIVPROC _glGetFramebufferParameteriv;
PFNGLNAMEDFRAMEBUFFERPARAMETERIEXTPROC _glNamedFramebufferParameteriEXT;
PFNGLGETNAMEDFRAMEBUFFERPARAMETERIVEXTPROC _glGetNamedFramebufferParameterivEXT;
PFNGLGETINTERNALFORMATI64VPROC _glGetInternalformati64v;
PFNGLINVALIDATETEXSUBIMAGEPROC _glInvalidateTexSubImage;
PFNGLINVALIDATETEXIMAGEPROC _glInvalidateTexImage;
PFNGLINVALIDATEBUFFERSUBDATAPROC _glInvalidateBufferSubData;
PFNGLINVALIDATEBUFFERDATAPROC _glInvalidateBufferData;
PFNGLINVALIDATEFRAMEBUFFERPROC _glInvalidateFramebuffer;
PFNGLINVALIDATESUBFRAMEBUFFERPROC _glInvalidateSubFramebuffer;
PFNGLMULTIDRAWARRAYSINDIRECTPROC _glMultiDrawArraysIndirect;
PFNGLMULTIDRAWELEMENTSINDIRECTPROC _glMultiDrawElementsIndirect;
PFNGLGETPROGRAMINTERFACEIVPROC _glGetProgramInterfaceiv;
PFNGLGETPROGRAMRESOURCEINDEXPROC _glGetProgramResourceIndex;
PFNGLGETPROGRAMRESOURCENAMEPROC _glGetProgramResourceName;
PFNGLGETPROGRAMRESOURCEIVPROC _glGetProgramResourceiv;
PFNGLGETPROGRAMRESOURCELOCATIONPROC _glGetProgramResourceLocation;
PFNGLGETPROGRAMRESOURCELOCATIONINDEXPROC _glGetProgramResourceLocationIndex;
PFNGLSHADERSTORAGEBLOCKBINDINGPROC _glShaderStorageBlockBinding;
PFNGLTEXBUFFERRANGEPROC _glTexBufferRange;
PFNGLTEXTUREBUFFERRANGEEXTPROC _glTextureBufferRangeEXT;
PFNGLTEXSTORAGE2DMULTISAMPLEPROC _glTexStorage2DMultisample;
PFNGLTEXSTORAGE3DMULTISAMPLEPROC _glTexStorage3DMultisample;
PFNGLTEXTURESTORAGE2DMULTISAMPLEEXTPROC _glTextureStorage2DMultisampleEXT;
PFNGLTEXTURESTORAGE3DMULTISAMPLEEXTPROC _glTextureStorage3DMultisampleEXT;
};

extern struct glxw *glxw;

#define glCullFace (glxw->_glCullFace)
#define glFrontFace (glxw->_glFrontFace)
#define glHint (glxw->_glHint)
#define glLineWidth (glxw->_glLineWidth)
#define glPointSize (glxw->_glPointSize)
#define glPolygonMode (glxw->_glPolygonMode)
#define glScissor (glxw->_glScissor)
#define glTexParameterf (glxw->_glTexParameterf)
#define glTexParameterfv (glxw->_glTexParameterfv)
#define glTexParameteri (glxw->_glTexParameteri)
#define glTexParameteriv (glxw->_glTexParameteriv)
#define glTexImage1D (glxw->_glTexImage1D)
#define glTexImage2D (glxw->_glTexImage2D)
#define glDrawBuffer (glxw->_glDrawBuffer)
#define glClear (glxw->_glClear)
#define glClearColor (glxw->_glClearColor)
#define glClearStencil (glxw->_glClearStencil)
#define glClearDepth (glxw->_glClearDepth)
#define glStencilMask (glxw->_glStencilMask)
#define glColorMask (glxw->_glColorMask)
#define glDepthMask (glxw->_glDepthMask)
#define glDisable (glxw->_glDisable)
#define glEnable (glxw->_glEnable)
#define glFinish (glxw->_glFinish)
#define glFlush (glxw->_glFlush)
#define glBlendFunc (glxw->_glBlendFunc)
#define glLogicOp (glxw->_glLogicOp)
#define glStencilFunc (glxw->_glStencilFunc)
#define glStencilOp (glxw->_glStencilOp)
#define glDepthFunc (glxw->_glDepthFunc)
#define glPixelStoref (glxw->_glPixelStoref)
#define glPixelStorei (glxw->_glPixelStorei)
#define glReadBuffer (glxw->_glReadBuffer)
#define glReadPixels (glxw->_glReadPixels)
#define glGetBooleanv (glxw->_glGetBooleanv)
#define glGetDoublev (glxw->_glGetDoublev)
#define glGetError (glxw->_glGetError)
#define glGetFloatv (glxw->_glGetFloatv)
#define glGetIntegerv (glxw->_glGetIntegerv)
#define glGetString (glxw->_glGetString)
#define glGetTexImage (glxw->_glGetTexImage)
#define glGetTexParameterfv (glxw->_glGetTexParameterfv)
#define glGetTexParameteriv (glxw->_glGetTexParameteriv)
#define glGetTexLevelParameterfv (glxw->_glGetTexLevelParameterfv)
#define glGetTexLevelParameteriv (glxw->_glGetTexLevelParameteriv)
#define glIsEnabled (glxw->_glIsEnabled)
#define glDepthRange (glxw->_glDepthRange)
#define glViewport (glxw->_glViewport)
#define glDrawArrays (glxw->_glDrawArrays)
#define glDrawElements (glxw->_glDrawElements)
#define glGetPointerv (glxw->_glGetPointerv)
#define glPolygonOffset (glxw->_glPolygonOffset)
#define glCopyTexImage1D (glxw->_glCopyTexImage1D)
#define glCopyTexImage2D (glxw->_glCopyTexImage2D)
#define glCopyTexSubImage1D (glxw->_glCopyTexSubImage1D)
#define glCopyTexSubImage2D (glxw->_glCopyTexSubImage2D)
#define glTexSubImage1D (glxw->_glTexSubImage1D)
#define glTexSubImage2D (glxw->_glTexSubImage2D)
#define glBindTexture (glxw->_glBindTexture)
#define glDeleteTextures (glxw->_glDeleteTextures)
#define glGenTextures (glxw->_glGenTextures)
#define glIsTexture (glxw->_glIsTexture)
#define glBlendColor (glxw->_glBlendColor)
#define glBlendEquation (glxw->_glBlendEquation)
#define glDrawRangeElements (glxw->_glDrawRangeElements)
#define glTexImage3D (glxw->_glTexImage3D)
#define glTexSubImage3D (glxw->_glTexSubImage3D)
#define glCopyTexSubImage3D (glxw->_glCopyTexSubImage3D)
#define glActiveTexture (glxw->_glActiveTexture)
#define glSampleCoverage (glxw->_glSampleCoverage)
#define glCompressedTexImage3D (glxw->_glCompressedTexImage3D)
#define glCompressedTexImage2D (glxw->_glCompressedTexImage2D)
#define glCompressedTexImage1D (glxw->_glCompressedTexImage1D)
#define glCompressedTexSubImage3D (glxw->_glCompressedTexSubImage3D)
#define glCompressedTexSubImage2D (glxw->_glCompressedTexSubImage2D)
#define glCompressedTexSubImage1D (glxw->_glCompressedTexSubImage1D)
#define glGetCompressedTexImage (glxw->_glGetCompressedTexImage)
#define glBlendFuncSeparate (glxw->_glBlendFuncSeparate)
#define glMultiDrawArrays (glxw->_glMultiDrawArrays)
#define glMultiDrawElements (glxw->_glMultiDrawElements)
#define glPointParameterf (glxw->_glPointParameterf)
#define glPointParameterfv (glxw->_glPointParameterfv)
#define glPointParameteri (glxw->_glPointParameteri)
#define glPointParameteriv (glxw->_glPointParameteriv)
#define glGenQueries (glxw->_glGenQueries)
#define glDeleteQueries (glxw->_glDeleteQueries)
#define glIsQuery (glxw->_glIsQuery)
#define glBeginQuery (glxw->_glBeginQuery)
#define glEndQuery (glxw->_glEndQuery)
#define glGetQueryiv (glxw->_glGetQueryiv)
#define glGetQueryObjectiv (glxw->_glGetQueryObjectiv)
#define glGetQueryObjectuiv (glxw->_glGetQueryObjectuiv)
#define glBindBuffer (glxw->_glBindBuffer)
#define glDeleteBuffers (glxw->_glDeleteBuffers)
#define glGenBuffers (glxw->_glGenBuffers)
#define glIsBuffer (glxw->_glIsBuffer)
#define glBufferData (glxw->_glBufferData)
#define glBufferSubData (glxw->_glBufferSubData)
#define glGetBufferSubData (glxw->_glGetBufferSubData)
#define glMapBuffer (glxw->_glMapBuffer)
#define glUnmapBuffer (glxw->_glUnmapBuffer)
#define glGetBufferParameteriv (glxw->_glGetBufferParameteriv)
#define glGetBufferPointerv (glxw->_glGetBufferPointerv)
#define glBlendEquationSeparate (glxw->_glBlendEquationSeparate)
#define glDrawBuffers (glxw->_glDrawBuffers)
#define glStencilOpSeparate (glxw->_glStencilOpSeparate)
#define glStencilFuncSeparate (glxw->_glStencilFuncSeparate)
#define glStencilMaskSeparate (glxw->_glStencilMaskSeparate)
#define glAttachShader (glxw->_glAttachShader)
#define glBindAttribLocation (glxw->_glBindAttribLocation)
#define glCompileShader (glxw->_glCompileShader)
#define glCreateProgram (glxw->_glCreateProgram)
#define glCreateShader (glxw->_glCreateShader)
#define glDeleteProgram (glxw->_glDeleteProgram)
#define glDeleteShader (glxw->_glDeleteShader)
#define glDetachShader (glxw->_glDetachShader)
#define glDisableVertexAttribArray (glxw->_glDisableVertexAttribArray)
#define glEnableVertexAttribArray (glxw->_glEnableVertexAttribArray)
#define glGetActiveAttrib (glxw->_glGetActiveAttrib)
#define glGetActiveUniform (glxw->_glGetActiveUniform)
#define glGetAttachedShaders (glxw->_glGetAttachedShaders)
#define glGetAttribLocation (glxw->_glGetAttribLocation)
#define glGetProgramiv (glxw->_glGetProgramiv)
#define glGetProgramInfoLog (glxw->_glGetProgramInfoLog)
#define glGetShaderiv (glxw->_glGetShaderiv)
#define glGetShaderInfoLog (glxw->_glGetShaderInfoLog)
#define glGetShaderSource (glxw->_glGetShaderSource)
#define glGetUniformLocation (glxw->_glGetUniformLocation)
#define glGetUniformfv (glxw->_glGetUniformfv)
#define glGetUniformiv (glxw->_glGetUniformiv)
#define glGetVertexAttribdv (glxw->_glGetVertexAttribdv)
#define glGetVertexAttribfv (glxw->_glGetVertexAttribfv)
#define glGetVertexAttribiv (glxw->_glGetVertexAttribiv)
#define glGetVertexAttribPointerv (glxw->_glGetVertexAttribPointerv)
#define glIsProgram (glxw->_glIsProgram)
#define glIsShader (glxw->_glIsShader)
#define glLinkProgram (glxw->_glLinkProgram)
#define glShaderSource (glxw->_glShaderSource)
#define glUseProgram (glxw->_glUseProgram)
#define glUniform1f (glxw->_glUniform1f)
#define glUniform2f (glxw->_glUniform2f)
#define glUniform3f (glxw->_glUniform3f)
#define glUniform4f (glxw->_glUniform4f)
#define glUniform1i (glxw->_glUniform1i)
#define glUniform2i (glxw->_glUniform2i)
#define glUniform3i (glxw->_glUniform3i)
#define glUniform4i (glxw->_glUniform4i)
#define glUniform1fv (glxw->_glUniform1fv)
#define glUniform2fv (glxw->_glUniform2fv)
#define glUniform3fv (glxw->_glUniform3fv)
#define glUniform4fv (glxw->_glUniform4fv)
#define glUniform1iv (glxw->_glUniform1iv)
#define glUniform2iv (glxw->_glUniform2iv)
#define glUniform3iv (glxw->_glUniform3iv)
#define glUniform4iv (glxw->_glUniform4iv)
#define glUniformMatrix2fv (glxw->_glUniformMatrix2fv)
#define glUniformMatrix3fv (glxw->_glUniformMatrix3fv)
#define glUniformMatrix4fv (glxw->_glUniformMatrix4fv)
#define glValidateProgram (glxw->_glValidateProgram)
#define glVertexAttrib1d (glxw->_glVertexAttrib1d)
#define glVertexAttrib1dv (glxw->_glVertexAttrib1dv)
#define glVertexAttrib1f (glxw->_glVertexAttrib1f)
#define glVertexAttrib1fv (glxw->_glVertexAttrib1fv)
#define glVertexAttrib1s (glxw->_glVertexAttrib1s)
#define glVertexAttrib1sv (glxw->_glVertexAttrib1sv)
#define glVertexAttrib2d (glxw->_glVertexAttrib2d)
#define glVertexAttrib2dv (glxw->_glVertexAttrib2dv)
#define glVertexAttrib2f (glxw->_glVertexAttrib2f)
#define glVertexAttrib2fv (glxw->_glVertexAttrib2fv)
#define glVertexAttrib2s (glxw->_glVertexAttrib2s)
#define glVertexAttrib2sv (glxw->_glVertexAttrib2sv)
#define glVertexAttrib3d (glxw->_glVertexAttrib3d)
#define glVertexAttrib3dv (glxw->_glVertexAttrib3dv)
#define glVertexAttrib3f (glxw->_glVertexAttrib3f)
#define glVertexAttrib3fv (glxw->_glVertexAttrib3fv)
#define glVertexAttrib3s (glxw->_glVertexAttrib3s)
#define glVertexAttrib3sv (glxw->_glVertexAttrib3sv)
#define glVertexAttrib4Nbv (glxw->_glVertexAttrib4Nbv)
#define glVertexAttrib4Niv (glxw->_glVertexAttrib4Niv)
#define glVertexAttrib4Nsv (glxw->_glVertexAttrib4Nsv)
#define glVertexAttrib4Nub (glxw->_glVertexAttrib4Nub)
#define glVertexAttrib4Nubv (glxw->_glVertexAttrib4Nubv)
#define glVertexAttrib4Nuiv (glxw->_glVertexAttrib4Nuiv)
#define glVertexAttrib4Nusv (glxw->_glVertexAttrib4Nusv)
#define glVertexAttrib4bv (glxw->_glVertexAttrib4bv)
#define glVertexAttrib4d (glxw->_glVertexAttrib4d)
#define glVertexAttrib4dv (glxw->_glVertexAttrib4dv)
#define glVertexAttrib4f (glxw->_glVertexAttrib4f)
#define glVertexAttrib4fv (glxw->_glVertexAttrib4fv)
#define glVertexAttrib4iv (glxw->_glVertexAttrib4iv)
#define glVertexAttrib4s (glxw->_glVertexAttrib4s)
#define glVertexAttrib4sv (glxw->_glVertexAttrib4sv)
#define glVertexAttrib4ubv (glxw->_glVertexAttrib4ubv)
#define glVertexAttrib4uiv (glxw->_glVertexAttrib4uiv)
#define glVertexAttrib4usv (glxw->_glVertexAttrib4usv)
#define glVertexAttribPointer (glxw->_glVertexAttribPointer)
#define glUniformMatrix2x3fv (glxw->_glUniformMatrix2x3fv)
#define glUniformMatrix3x2fv (glxw->_glUniformMatrix3x2fv)
#define glUniformMatrix2x4fv (glxw->_glUniformMatrix2x4fv)
#define glUniformMatrix4x2fv (glxw->_glUniformMatrix4x2fv)
#define glUniformMatrix3x4fv (glxw->_glUniformMatrix3x4fv)
#define glUniformMatrix4x3fv (glxw->_glUniformMatrix4x3fv)
#define glColorMaski (glxw->_glColorMaski)
#define glGetBooleani_v (glxw->_glGetBooleani_v)
#define glGetIntegeri_v (glxw->_glGetIntegeri_v)
#define glEnablei (glxw->_glEnablei)
#define glDisablei (glxw->_glDisablei)
#define glIsEnabledi (glxw->_glIsEnabledi)
#define glBeginTransformFeedback (glxw->_glBeginTransformFeedback)
#define glEndTransformFeedback (glxw->_glEndTransformFeedback)
#define glBindBufferRange (glxw->_glBindBufferRange)
#define glBindBufferBase (glxw->_glBindBufferBase)
#define glTransformFeedbackVaryings (glxw->_glTransformFeedbackVaryings)
#define glGetTransformFeedbackVarying (glxw->_glGetTransformFeedbackVarying)
#define glClampColor (glxw->_glClampColor)
#define glBeginConditionalRender (glxw->_glBeginConditionalRender)
#define glEndConditionalRender (glxw->_glEndConditionalRender)
#define glVertexAttribIPointer (glxw->_glVertexAttribIPointer)
#define glGetVertexAttribIiv (glxw->_glGetVertexAttribIiv)
#define glGetVertexAttribIuiv (glxw->_glGetVertexAttribIuiv)
#define glVertexAttribI1i (glxw->_glVertexAttribI1i)
#define glVertexAttribI2i (glxw->_glVertexAttribI2i)
#define glVertexAttribI3i (glxw->_glVertexAttribI3i)
#define glVertexAttribI4i (glxw->_glVertexAttribI4i)
#define glVertexAttribI1ui (glxw->_glVertexAttribI1ui)
#define glVertexAttribI2ui (glxw->_glVertexAttribI2ui)
#define glVertexAttribI3ui (glxw->_glVertexAttribI3ui)
#define glVertexAttribI4ui (glxw->_glVertexAttribI4ui)
#define glVertexAttribI1iv (glxw->_glVertexAttribI1iv)
#define glVertexAttribI2iv (glxw->_glVertexAttribI2iv)
#define glVertexAttribI3iv (glxw->_glVertexAttribI3iv)
#define glVertexAttribI4iv (glxw->_glVertexAttribI4iv)
#define glVertexAttribI1uiv (glxw->_glVertexAttribI1uiv)
#define glVertexAttribI2uiv (glxw->_glVertexAttribI2uiv)
#define glVertexAttribI3uiv (glxw->_glVertexAttribI3uiv)
#define glVertexAttribI4uiv (glxw->_glVertexAttribI4uiv)
#define glVertexAttribI4bv (glxw->_glVertexAttribI4bv)
#define glVertexAttribI4sv (glxw->_glVertexAttribI4sv)
#define glVertexAttribI4ubv (glxw->_glVertexAttribI4ubv)
#define glVertexAttribI4usv (glxw->_glVertexAttribI4usv)
#define glGetUniformuiv (glxw->_glGetUniformuiv)
#define glBindFragDataLocation (glxw->_glBindFragDataLocation)
#define glGetFragDataLocation (glxw->_glGetFragDataLocation)
#define glUniform1ui (glxw->_glUniform1ui)
#define glUniform2ui (glxw->_glUniform2ui)
#define glUniform3ui (glxw->_glUniform3ui)
#define glUniform4ui (glxw->_glUniform4ui)
#define glUniform1uiv (glxw->_glUniform1uiv)
#define glUniform2uiv (glxw->_glUniform2uiv)
#define glUniform3uiv (glxw->_glUniform3uiv)
#define glUniform4uiv (glxw->_glUniform4uiv)
#define glTexParameterIiv (glxw->_glTexParameterIiv)
#define glTexParameterIuiv (glxw->_glTexParameterIuiv)
#define glGetTexParameterIiv (glxw->_glGetTexParameterIiv)
#define glGetTexParameterIuiv (glxw->_glGetTexParameterIuiv)
#define glClearBufferiv (glxw->_glClearBufferiv)
#define glClearBufferuiv (glxw->_glClearBufferuiv)
#define glClearBufferfv (glxw->_glClearBufferfv)
#define glClearBufferfi (glxw->_glClearBufferfi)
#define glGetStringi (glxw->_glGetStringi)
#define glDrawArraysInstanced (glxw->_glDrawArraysInstanced)
#define glDrawElementsInstanced (glxw->_glDrawElementsInstanced)
#define glTexBuffer (glxw->_glTexBuffer)
#define glPrimitiveRestartIndex (glxw->_glPrimitiveRestartIndex)
#define glGetInteger64i_v (glxw->_glGetInteger64i_v)
#define glGetBufferParameteri64v (glxw->_glGetBufferParameteri64v)
#define glFramebufferTexture (glxw->_glFramebufferTexture)
#define glVertexAttribDivisor (glxw->_glVertexAttribDivisor)
#define glMinSampleShading (glxw->_glMinSampleShading)
#define glBlendEquationi (glxw->_glBlendEquationi)
#define glBlendEquationSeparatei (glxw->_glBlendEquationSeparatei)
#define glBlendFunci (glxw->_glBlendFunci)
#define glBlendFuncSeparatei (glxw->_glBlendFuncSeparatei)
#define glIsRenderbuffer (glxw->_glIsRenderbuffer)
#define glBindRenderbuffer (glxw->_glBindRenderbuffer)
#define glDeleteRenderbuffers (glxw->_glDeleteRenderbuffers)
#define glGenRenderbuffers (glxw->_glGenRenderbuffers)
#define glRenderbufferStorage (glxw->_glRenderbufferStorage)
#define glGetRenderbufferParameteriv (glxw->_glGetRenderbufferParameteriv)
#define glIsFramebuffer (glxw->_glIsFramebuffer)
#define glBindFramebuffer (glxw->_glBindFramebuffer)
#define glDeleteFramebuffers (glxw->_glDeleteFramebuffers)
#define glGenFramebuffers (glxw->_glGenFramebuffers)
#define glCheckFramebufferStatus (glxw->_glCheckFramebufferStatus)
#define glFramebufferTexture1D (glxw->_glFramebufferTexture1D)
#define glFramebufferTexture2D (glxw->_glFramebufferTexture2D)
#define glFramebufferTexture3D (glxw->_glFramebufferTexture3D)
#define glFramebufferRenderbuffer (glxw->_glFramebufferRenderbuffer)
#define glGetFramebufferAttachmentParameteriv (glxw->_glGetFramebufferAttachmentParameteriv)
#define glGenerateMipmap (glxw->_glGenerateMipmap)
#define glBlitFramebuffer (glxw->_glBlitFramebuffer)
#define glRenderbufferStorageMultisample (glxw->_glRenderbufferStorageMultisample)
#define glFramebufferTextureLayer (glxw->_glFramebufferTextureLayer)
#define glMapBufferRange (glxw->_glMapBufferRange)
#define glFlushMappedBufferRange (glxw->_glFlushMappedBufferRange)
#define glBindVertexArray (glxw->_glBindVertexArray)
#define glDeleteVertexArrays (glxw->_glDeleteVertexArrays)
#define glGenVertexArrays (glxw->_glGenVertexArrays)
#define glIsVertexArray (glxw->_glIsVertexArray)
#define glGetUniformIndices (glxw->_glGetUniformIndices)
#define glGetActiveUniformsiv (glxw->_glGetActiveUniformsiv)
#define glGetActiveUniformName (glxw->_glGetActiveUniformName)
#define glGetUniformBlockIndex (glxw->_glGetUniformBlockIndex)
#define glGetActiveUniformBlockiv (glxw->_glGetActiveUniformBlockiv)
#define glGetActiveUniformBlockName (glxw->_glGetActiveUniformBlockName)
#define glUniformBlockBinding (glxw->_glUniformBlockBinding)
#define glCopyBufferSubData (glxw->_glCopyBufferSubData)
#define glDrawElementsBaseVertex (glxw->_glDrawElementsBaseVertex)
#define glDrawRangeElementsBaseVertex (glxw->_glDrawRangeElementsBaseVertex)
#define glDrawElementsInstancedBaseVertex (glxw->_glDrawElementsInstancedBaseVertex)
#define glMultiDrawElementsBaseVertex (glxw->_glMultiDrawElementsBaseVertex)
#define glProvokingVertex (glxw->_glProvokingVertex)
#define glFenceSync (glxw->_glFenceSync)
#define glIsSync (glxw->_glIsSync)
#define glDeleteSync (glxw->_glDeleteSync)
#define glClientWaitSync (glxw->_glClientWaitSync)
#define glWaitSync (glxw->_glWaitSync)
#define glGetInteger64v (glxw->_glGetInteger64v)
#define glGetSynciv (glxw->_glGetSynciv)
#define glTexImage2DMultisample (glxw->_glTexImage2DMultisample)
#define glTexImage3DMultisample (glxw->_glTexImage3DMultisample)
#define glGetMultisamplefv (glxw->_glGetMultisamplefv)
#define glSampleMaski (glxw->_glSampleMaski)
#define glBlendEquationiARB (glxw->_glBlendEquationiARB)
#define glBlendEquationSeparateiARB (glxw->_glBlendEquationSeparateiARB)
#define glBlendFunciARB (glxw->_glBlendFunciARB)
#define glBlendFuncSeparateiARB (glxw->_glBlendFuncSeparateiARB)
#define glMinSampleShadingARB (glxw->_glMinSampleShadingARB)
#define glNamedStringARB (glxw->_glNamedStringARB)
#define glDeleteNamedStringARB (glxw->_glDeleteNamedStringARB)
#define glCompileShaderIncludeARB (glxw->_glCompileShaderIncludeARB)
#define glIsNamedStringARB (glxw->_glIsNamedStringARB)
#define glGetNamedStringARB (glxw->_glGetNamedStringARB)
#define glGetNamedStringivARB (glxw->_glGetNamedStringivARB)
#define glBindFragDataLocationIndexed (glxw->_glBindFragDataLocationIndexed)
#define glGetFragDataIndex (glxw->_glGetFragDataIndex)
#define glGenSamplers (glxw->_glGenSamplers)
#define glDeleteSamplers (glxw->_glDeleteSamplers)
#define glIsSampler (glxw->_glIsSampler)
#define glBindSampler (glxw->_glBindSampler)
#define glSamplerParameteri (glxw->_glSamplerParameteri)
#define glSamplerParameteriv (glxw->_glSamplerParameteriv)
#define glSamplerParameterf (glxw->_glSamplerParameterf)
#define glSamplerParameterfv (glxw->_glSamplerParameterfv)
#define glSamplerParameterIiv (glxw->_glSamplerParameterIiv)
#define glSamplerParameterIuiv (glxw->_glSamplerParameterIuiv)
#define glGetSamplerParameteriv (glxw->_glGetSamplerParameteriv)
#define glGetSamplerParameterIiv (glxw->_glGetSamplerParameterIiv)
#define glGetSamplerParameterfv (glxw->_glGetSamplerParameterfv)
#define glGetSamplerParameterIuiv (glxw->_glGetSamplerParameterIuiv)
#define glQueryCounter (glxw->_glQueryCounter)
#define glGetQueryObjecti64v (glxw->_glGetQueryObjecti64v)
#define glGetQueryObjectui64v (glxw->_glGetQueryObjectui64v)
#define glVertexP2ui (glxw->_glVertexP2ui)
#define glVertexP2uiv (glxw->_glVertexP2uiv)
#define glVertexP3ui (glxw->_glVertexP3ui)
#define glVertexP3uiv (glxw->_glVertexP3uiv)
#define glVertexP4ui (glxw->_glVertexP4ui)
#define glVertexP4uiv (glxw->_glVertexP4uiv)
#define glTexCoordP1ui (glxw->_glTexCoordP1ui)
#define glTexCoordP1uiv (glxw->_glTexCoordP1uiv)
#define glTexCoordP2ui (glxw->_glTexCoordP2ui)
#define glTexCoordP2uiv (glxw->_glTexCoordP2uiv)
#define glTexCoordP3ui (glxw->_glTexCoordP3ui)
#define glTexCoordP3uiv (glxw->_glTexCoordP3uiv)
#define glTexCoordP4ui (glxw->_glTexCoordP4ui)
#define glTexCoordP4uiv (glxw->_glTexCoordP4uiv)
#define glMultiTexCoordP1ui (glxw->_glMultiTexCoordP1ui)
#define glMultiTexCoordP1uiv (glxw->_glMultiTexCoordP1uiv)
#define glMultiTexCoordP2ui (glxw->_glMultiTexCoordP2ui)
#define glMultiTexCoordP2uiv (glxw->_glMultiTexCoordP2uiv)
#define glMultiTexCoordP3ui (glxw->_glMultiTexCoordP3ui)
#define glMultiTexCoordP3uiv (glxw->_glMultiTexCoordP3uiv)
#define glMultiTexCoordP4ui (glxw->_glMultiTexCoordP4ui)
#define glMultiTexCoordP4uiv (glxw->_glMultiTexCoordP4uiv)
#define glNormalP3ui (glxw->_glNormalP3ui)
#define glNormalP3uiv (glxw->_glNormalP3uiv)
#define glColorP3ui (glxw->_glColorP3ui)
#define glColorP3uiv (glxw->_glColorP3uiv)
#define glColorP4ui (glxw->_glColorP4ui)
#define glColorP4uiv (glxw->_glColorP4uiv)
#define glSecondaryColorP3ui (glxw->_glSecondaryColorP3ui)
#define glSecondaryColorP3uiv (glxw->_glSecondaryColorP3uiv)
#define glVertexAttribP1ui (glxw->_glVertexAttribP1ui)
#define glVertexAttribP1uiv (glxw->_glVertexAttribP1uiv)
#define glVertexAttribP2ui (glxw->_glVertexAttribP2ui)
#define glVertexAttribP2uiv (glxw->_glVertexAttribP2uiv)
#define glVertexAttribP3ui (glxw->_glVertexAttribP3ui)
#define glVertexAttribP3uiv (glxw->_glVertexAttribP3uiv)
#define glVertexAttribP4ui (glxw->_glVertexAttribP4ui)
#define glVertexAttribP4uiv (glxw->_glVertexAttribP4uiv)
#define glDrawArraysIndirect (glxw->_glDrawArraysIndirect)
#define glDrawElementsIndirect (glxw->_glDrawElementsIndirect)
#define glUniform1d (glxw->_glUniform1d)
#define glUniform2d (glxw->_glUniform2d)
#define glUniform3d (glxw->_glUniform3d)
#define glUniform4d (glxw->_glUniform4d)
#define glUniform1dv (glxw->_glUniform1dv)
#define glUniform2dv (glxw->_glUniform2dv)
#define glUniform3dv (glxw->_glUniform3dv)
#define glUniform4dv (glxw->_glUniform4dv)
#define glUniformMatrix2dv (glxw->_glUniformMatrix2dv)
#define glUniformMatrix3dv (glxw->_glUniformMatrix3dv)
#define glUniformMatrix4dv (glxw->_glUniformMatrix4dv)
#define glUniformMatrix2x3dv (glxw->_glUniformMatrix2x3dv)
#define glUniformMatrix2x4dv (glxw->_glUniformMatrix2x4dv)
#define glUniformMatrix3x2dv (glxw->_glUniformMatrix3x2dv)
#define glUniformMatrix3x4dv (glxw->_glUniformMatrix3x4dv)
#define glUniformMatrix4x2dv (glxw->_glUniformMatrix4x2dv)
#define glUniformMatrix4x3dv (glxw->_glUniformMatrix4x3dv)
#define glGetUniformdv (glxw->_glGetUniformdv)
#define glGetSubroutineUniformLocation (glxw->_glGetSubroutineUniformLocation)
#define glGetSubroutineIndex (glxw->_glGetSubroutineIndex)
#define glGetActiveSubroutineUniformiv (glxw->_glGetActiveSubroutineUniformiv)
#define glGetActiveSubroutineUniformName (glxw->_glGetActiveSubroutineUniformName)
#define glGetActiveSubroutineName (glxw->_glGetActiveSubroutineName)
#define glUniformSubroutinesuiv (glxw->_glUniformSubroutinesuiv)
#define glGetUniformSubroutineuiv (glxw->_glGetUniformSubroutineuiv)
#define glGetProgramStageiv (glxw->_glGetProgramStageiv)
#define glPatchParameteri (glxw->_glPatchParameteri)
#define glPatchParameterfv (glxw->_glPatchParameterfv)
#define glBindTransformFeedback (glxw->_glBindTransformFeedback)
#define glDeleteTransformFeedbacks (glxw->_glDeleteTransformFeedbacks)
#define glGenTransformFeedbacks (glxw->_glGenTransformFeedbacks)
#define glIsTransformFeedback (glxw->_glIsTransformFeedback)
#define glPauseTransformFeedback (glxw->_glPauseTransformFeedback)
#define glResumeTransformFeedback (glxw->_glResumeTransformFeedback)
#define glDrawTransformFeedback (glxw->_glDrawTransformFeedback)
#define glDrawTransformFeedbackStream (glxw->_glDrawTransformFeedbackStream)
#define glBeginQueryIndexed (glxw->_glBeginQueryIndexed)
#define glEndQueryIndexed (glxw->_glEndQueryIndexed)
#define glGetQueryIndexediv (glxw->_glGetQueryIndexediv)
#define glReleaseShaderCompiler (glxw->_glReleaseShaderCompiler)
#define glShaderBinary (glxw->_glShaderBinary)
#define glGetShaderPrecisionFormat (glxw->_glGetShaderPrecisionFormat)
#define glDepthRangef (glxw->_glDepthRangef)
#define glClearDepthf (glxw->_glClearDepthf)
#define glGetProgramBinary (glxw->_glGetProgramBinary)
#define glProgramBinary (glxw->_glProgramBinary)
#define glProgramParameteri (glxw->_glProgramParameteri)
#define glUseProgramStages (glxw->_glUseProgramStages)
#define glActiveShaderProgram (glxw->_glActiveShaderProgram)
#define glCreateShaderProgramv (glxw->_glCreateShaderProgramv)
#define glBindProgramPipeline (glxw->_glBindProgramPipeline)
#define glDeleteProgramPipelines (glxw->_glDeleteProgramPipelines)
#define glGenProgramPipelines (glxw->_glGenProgramPipelines)
#define glIsProgramPipeline (glxw->_glIsProgramPipeline)
#define glGetProgramPipelineiv (glxw->_glGetProgramPipelineiv)
#define glProgramUniform1i (glxw->_glProgramUniform1i)
#define glProgramUniform1iv (glxw->_glProgramUniform1iv)
#define glProgramUniform1f (glxw->_glProgramUniform1f)
#define glProgramUniform1fv (glxw->_glProgramUniform1fv)
#define glProgramUniform1d (glxw->_glProgramUniform1d)
#define glProgramUniform1dv (glxw->_glProgramUniform1dv)
#define glProgramUniform1ui (glxw->_glProgramUniform1ui)
#define glProgramUniform1uiv (glxw->_glProgramUniform1uiv)
#define glProgramUniform2i (glxw->_glProgramUniform2i)
#define glProgramUniform2iv (glxw->_glProgramUniform2iv)
#define glProgramUniform2f (glxw->_glProgramUniform2f)
#define glProgramUniform2fv (glxw->_glProgramUniform2fv)
#define glProgramUniform2d (glxw->_glProgramUniform2d)
#define glProgramUniform2dv (glxw->_glProgramUniform2dv)
#define glProgramUniform2ui (glxw->_glProgramUniform2ui)
#define glProgramUniform2uiv (glxw->_glProgramUniform2uiv)
#define glProgramUniform3i (glxw->_glProgramUniform3i)
#define glProgramUniform3iv (glxw->_glProgramUniform3iv)
#define glProgramUniform3f (glxw->_glProgramUniform3f)
#define glProgramUniform3fv (glxw->_glProgramUniform3fv)
#define glProgramUniform3d (glxw->_glProgramUniform3d)
#define glProgramUniform3dv (glxw->_glProgramUniform3dv)
#define glProgramUniform3ui (glxw->_glProgramUniform3ui)
#define glProgramUniform3uiv (glxw->_glProgramUniform3uiv)
#define glProgramUniform4i (glxw->_glProgramUniform4i)
#define glProgramUniform4iv (glxw->_glProgramUniform4iv)
#define glProgramUniform4f (glxw->_glProgramUniform4f)
#define glProgramUniform4fv (glxw->_glProgramUniform4fv)
#define glProgramUniform4d (glxw->_glProgramUniform4d)
#define glProgramUniform4dv (glxw->_glProgramUniform4dv)
#define glProgramUniform4ui (glxw->_glProgramUniform4ui)
#define glProgramUniform4uiv (glxw->_glProgramUniform4uiv)
#define glProgramUniformMatrix2fv (glxw->_glProgramUniformMatrix2fv)
#define glProgramUniformMatrix3fv (glxw->_glProgramUniformMatrix3fv)
#define glProgramUniformMatrix4fv (glxw->_glProgramUniformMatrix4fv)
#define glProgramUniformMatrix2dv (glxw->_glProgramUniformMatrix2dv)
#define glProgramUniformMatrix3dv (glxw->_glProgramUniformMatrix3dv)
#define glProgramUniformMatrix4dv (glxw->_glProgramUniformMatrix4dv)
#define glProgramUniformMatrix2x3fv (glxw->_glProgramUniformMatrix2x3fv)
#define glProgramUniformMatrix3x2fv (glxw->_glProgramUniformMatrix3x2fv)
#define glProgramUniformMatrix2x4fv (glxw->_glProgramUniformMatrix2x4fv)
#define glProgramUniformMatrix4x2fv (glxw->_glProgramUniformMatrix4x2fv)
#define glProgramUniformMatrix3x4fv (glxw->_glProgramUniformMatrix3x4fv)
#define glProgramUniformMatrix4x3fv (glxw->_glProgramUniformMatrix4x3fv)
#define glProgramUniformMatrix2x3dv (glxw->_glProgramUniformMatrix2x3dv)
#define glProgramUniformMatrix3x2dv (glxw->_glProgramUniformMatrix3x2dv)
#define glProgramUniformMatrix2x4dv (glxw->_glProgramUniformMatrix2x4dv)
#define glProgramUniformMatrix4x2dv (glxw->_glProgramUniformMatrix4x2dv)
#define glProgramUniformMatrix3x4dv (glxw->_glProgramUniformMatrix3x4dv)
#define glProgramUniformMatrix4x3dv (glxw->_glProgramUniformMatrix4x3dv)
#define glValidateProgramPipeline (glxw->_glValidateProgramPipeline)
#define glGetProgramPipelineInfoLog (glxw->_glGetProgramPipelineInfoLog)
#define glVertexAttribL1d (glxw->_glVertexAttribL1d)
#define glVertexAttribL2d (glxw->_glVertexAttribL2d)
#define glVertexAttribL3d (glxw->_glVertexAttribL3d)
#define glVertexAttribL4d (glxw->_glVertexAttribL4d)
#define glVertexAttribL1dv (glxw->_glVertexAttribL1dv)
#define glVertexAttribL2dv (glxw->_glVertexAttribL2dv)
#define glVertexAttribL3dv (glxw->_glVertexAttribL3dv)
#define glVertexAttribL4dv (glxw->_glVertexAttribL4dv)
#define glVertexAttribLPointer (glxw->_glVertexAttribLPointer)
#define glGetVertexAttribLdv (glxw->_glGetVertexAttribLdv)
#define glViewportArrayv (glxw->_glViewportArrayv)
#define glViewportIndexedf (glxw->_glViewportIndexedf)
#define glViewportIndexedfv (glxw->_glViewportIndexedfv)
#define glScissorArrayv (glxw->_glScissorArrayv)
#define glScissorIndexed (glxw->_glScissorIndexed)
#define glScissorIndexedv (glxw->_glScissorIndexedv)
#define glDepthRangeArrayv (glxw->_glDepthRangeArrayv)
#define glDepthRangeIndexed (glxw->_glDepthRangeIndexed)
#define glGetFloati_v (glxw->_glGetFloati_v)
#define glGetDoublei_v (glxw->_glGetDoublei_v)
#define glCreateSyncFromCLeventARB (glxw->_glCreateSyncFromCLeventARB)
#define glDebugMessageControlARB (glxw->_glDebugMessageControlARB)
#define glDebugMessageInsertARB (glxw->_glDebugMessageInsertARB)
#define glDebugMessageCallbackARB (glxw->_glDebugMessageCallbackARB)
#define glGetDebugMessageLogARB (glxw->_glGetDebugMessageLogARB)
#define glGetGraphicsResetStatusARB (glxw->_glGetGraphicsResetStatusARB)
#define glGetnTexImageARB (glxw->_glGetnTexImageARB)
#define glReadnPixelsARB (glxw->_glReadnPixelsARB)
#define glGetnCompressedTexImageARB (glxw->_glGetnCompressedTexImageARB)
#define glGetnUniformfvARB (glxw->_glGetnUniformfvARB)
#define glGetnUniformivARB (glxw->_glGetnUniformivARB)
#define glGetnUniformuivARB (glxw->_glGetnUniformuivARB)
#define glGetnUniformdvARB (glxw->_glGetnUniformdvARB)
#define glDrawArraysInstancedBaseInstance (glxw->_glDrawArraysInstancedBaseInstance)
#define glDrawElementsInstancedBaseInstance (glxw->_glDrawElementsInstancedBaseInstance)
#define glDrawElementsInstancedBaseVertexBaseInstance (glxw->_glDrawElementsInstancedBaseVertexBaseInstance)
#define glDrawTransformFeedbackInstanced (glxw->_glDrawTransformFeedbackInstanced)
#define glDrawTransformFeedbackStreamInstanced (glxw->_glDrawTransformFeedbackStreamInstanced)
#define glGetInternalformativ (glxw->_glGetInternalformativ)
#define glGetActiveAtomicCounterBufferiv (glxw->_glGetActiveAtomicCounterBufferiv)
#define glBindImageTexture (glxw->_glBindImageTexture)
#define glMemoryBarrier (glxw->_glMemoryBarrier)
#define glTexStorage1D (glxw->_glTexStorage1D)
#define glTexStorage2D (glxw->_glTexStorage2D)
#define glTexStorage3D (glxw->_glTexStorage3D)
#define glTextureStorage1DEXT (glxw->_glTextureStorage1DEXT)
#define glTextureStorage2DEXT (glxw->_glTextureStorage2DEXT)
#define glTextureStorage3DEXT (glxw->_glTextureStorage3DEXT)
#define glDebugMessageControl (glxw->_glDebugMessageControl)
#define glDebugMessageInsert (glxw->_glDebugMessageInsert)
#define glDebugMessageCallback (glxw->_glDebugMessageCallback)
#define glGetDebugMessageLog (glxw->_glGetDebugMessageLog)
#define glPushDebugGroup (glxw->_glPushDebugGroup)
#define glPopDebugGroup (glxw->_glPopDebugGroup)
#define glObjectLabel (glxw->_glObjectLabel)
#define glGetObjectLabel (glxw->_glGetObjectLabel)
#define glObjectPtrLabel (glxw->_glObjectPtrLabel)
#define glGetObjectPtrLabel (glxw->_glGetObjectPtrLabel)
#define glClearBufferData (glxw->_glClearBufferData)
#define glClearBufferSubData (glxw->_glClearBufferSubData)
#define glClearNamedBufferDataEXT (glxw->_glClearNamedBufferDataEXT)
#define glClearNamedBufferSubDataEXT (glxw->_glClearNamedBufferSubDataEXT)
#define glDispatchCompute (glxw->_glDispatchCompute)
#define glDispatchComputeIndirect (glxw->_glDispatchComputeIndirect)
#define glCopyImageSubData (glxw->_glCopyImageSubData)
#define glTextureView (glxw->_glTextureView)
#define glBindVertexBuffer (glxw->_glBindVertexBuffer)
#define glVertexAttribFormat (glxw->_glVertexAttribFormat)
#define glVertexAttribIFormat (glxw->_glVertexAttribIFormat)
#define glVertexAttribLFormat (glxw->_glVertexAttribLFormat)
#define glVertexAttribBinding (glxw->_glVertexAttribBinding)
#define glVertexBindingDivisor (glxw->_glVertexBindingDivisor)
#define glVertexArrayBindVertexBufferEXT (glxw->_glVertexArrayBindVertexBufferEXT)
#define glVertexArrayVertexAttribFormatEXT (glxw->_glVertexArrayVertexAttribFormatEXT)
#define glVertexArrayVertexAttribIFormatEXT (glxw->_glVertexArrayVertexAttribIFormatEXT)
#define glVertexArrayVertexAttribLFormatEXT (glxw->_glVertexArrayVertexAttribLFormatEXT)
#define glVertexArrayVertexAttribBindingEXT (glxw->_glVertexArrayVertexAttribBindingEXT)
#define glVertexArrayVertexBindingDivisorEXT (glxw->_glVertexArrayVertexBindingDivisorEXT)
#define glFramebufferParameteri (glxw->_glFramebufferParameteri)
#define glGetFramebufferParameteriv (glxw->_glGetFramebufferParameteriv)
#define glNamedFramebufferParameteriEXT (glxw->_glNamedFramebufferParameteriEXT)
#define glGetNamedFramebufferParameterivEXT (glxw->_glGetNamedFramebufferParameterivEXT)
#define glGetInternalformati64v (glxw->_glGetInternalformati64v)
#define glInvalidateTexSubImage (glxw->_glInvalidateTexSubImage)
#define glInvalidateTexImage (glxw->_glInvalidateTexImage)
#define glInvalidateBufferSubData (glxw->_glInvalidateBufferSubData)
#define glInvalidateBufferData (glxw->_glInvalidateBufferData)
#define glInvalidateFramebuffer (glxw->_glInvalidateFramebuffer)
#define glInvalidateSubFramebuffer (glxw->_glInvalidateSubFramebuffer)
#define glMultiDrawArraysIndirect (glxw->_glMultiDrawArraysIndirect)
#define glMultiDrawElementsIndirect (glxw->_glMultiDrawElementsIndirect)
#define glGetProgramInterfaceiv (glxw->_glGetProgramInterfaceiv)
#define glGetProgramResourceIndex (glxw->_glGetProgramResourceIndex)
#define glGetProgramResourceName (glxw->_glGetProgramResourceName)
#define glGetProgramResourceiv (glxw->_glGetProgramResourceiv)
#define glGetProgramResourceLocation (glxw->_glGetProgramResourceLocation)
#define glGetProgramResourceLocationIndex (glxw->_glGetProgramResourceLocationIndex)
#define glShaderStorageBlockBinding (glxw->_glShaderStorageBlockBinding)
#define glTexBufferRange (glxw->_glTexBufferRange)
#define glTextureBufferRangeEXT (glxw->_glTextureBufferRangeEXT)
#define glTexStorage2DMultisample (glxw->_glTexStorage2DMultisample)
#define glTexStorage3DMultisample (glxw->_glTexStorage3DMultisample)
#define glTextureStorage2DMultisampleEXT (glxw->_glTextureStorage2DMultisampleEXT)
#define glTextureStorage3DMultisampleEXT (glxw->_glTextureStorage3DMultisampleEXT)

#ifdef __cplusplus
}
#endif

#endif
